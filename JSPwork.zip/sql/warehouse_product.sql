CREATE DATABASE  IF NOT EXISTS `warehouse` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `warehouse`;
-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: warehouse
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `ID` int NOT NULL,
  `title` varchar(30) DEFAULT NULL,
  `content` varchar(100) DEFAULT NULL,
  `picture` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,'神仙居风景名胜区','我在盛开的樱花下遇见你，从此命运不再属于自己。','./images/feature10.jpg'),(2,'漩门湾观光农业园','该生态园区植被丰富，树林茂盛，树枝茂密，冬可抵御寒风、夏秋可抗击热带风暴，有长度达到二十多公里、被誉为海上绿色长城的木麻黄防护林带。','./images/feature9.png'),(3,'大鹿岛','大鹿岛孤悬在烟波浩瀚的东海，距玉环坎门港6海里。常年被绿色所覆盖，山海风情并茂，如万顷碧波长缀的翡翠。','./images/feature8.png'),(4,'括苍山','括苍山是浙江名山之一，山势雄拔陡绝，峰峦叠嶂。山上长年云雾缭绕，盘山公路自白云深处旋绕而下。','./images/feature2.png'),(5,'琼台仙谷景区','人文景观可用五句话来概括“黄帝铸鼎，历史悠久；神仙常驻，仙气长留；高道修真，开创南宗；文人咏赞，美景迭出；蓄能电站，光照神州。','./images/feature6.png'),(6,'蛇蟠岛','全岛面积约19.68平方公里，是台州第一大岛，是国内规模最大的海岛洞窟游览景区，是首部国际获奖影片《渔光曲》拍摄地。','./images/feature1.png'),(7,'长屿硐天','“屿不甚大而最有名，并石苍、黄监或统称‘长屿’。”长屿因风峦蜿蜒起伏，犹如海上一座狭长的岛屿而得名。','./images/feature7.png'),(8,'皤滩古镇','皤滩和江浙众多的古镇一样，依靠着水流，而这里的水流使得河滩上遍布鹅卵石，古镇的名字也源于此。','./images/feature5.png'),(9,'江南长城','江南长城婉美北方的长城，虽然没有北方万里长城的气魄，但不失雄伟和先人保护家园的智慧。','./images/feature4.png');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-19 13:47:47
