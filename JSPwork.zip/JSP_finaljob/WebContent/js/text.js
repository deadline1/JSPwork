var changes = document.getElementsByClassName('changes')[0];
var selected = changes.querySelectorAll('a');
var h = document.querySelector('h2');
console.log(h.innerText);
if(h.innerText == 'CHANGE-ADD') {
	selected[0].className = 'selected';
}
else if(h.innerText == 'CHANGE-DEL') {
	selected[1].className = 'selected';
}
else if(h.innerText == 'CHANGE-Update') {
	selected[2].className = 'selected';
}
else{
	selected[3].className = 'selected';
}